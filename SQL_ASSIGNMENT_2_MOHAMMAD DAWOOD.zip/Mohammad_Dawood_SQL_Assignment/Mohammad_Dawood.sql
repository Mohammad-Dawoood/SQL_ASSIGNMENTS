create schema superstores;
use superstores;
select * from cust_dimen ;
select * from market_fact ;
select * from orders_dimen ;
select * from prod_dimen ;
select * from shipping_dimen ;

-- ---1. Write a query to display the Customer_Name and Customer Segment using alias name “Customer Name", "Customer Segment" from table Cust_dimen. -----------

SELECT 
    customer_name AS 'Customer Name',
    Customer_Segment AS 'Customer Segment'
FROM
    Cust_dimen;


-- ---------------------2. Write a query to find all the details of the customer from the table cust_dimen order by desc. --------------------------------

SELECT 
    customer_name, cust_id, customer_segment
FROM
    cust_dimen
ORDER BY customer_name DESC;
    
    
-- -----------------------3. Write a query to get the Order ID, Order date from table orders_dimen where ‘Order Priority’ is high.-------------------


SELECT 
    order_id, order_date
FROM
    orders_dimen
WHERE
    order_priority = 'high' ;
    
-------------------------------- 4. Find the total and the average sales (display total_sales and avg_sales)----------------------------


SELECT 
    SUM(sales) 'Total Sales', AVG(sales) 'Average Sales'
FROM
    market_fact;
    
    
-------------------------------- 5. Write a query to get the maximum and minimum sales from maket_fact table.-------------------------------------


SELECT 
    MAX(sales) 'Maximum Sales', MIN(sales) 'Minimum Sales'
FROM
    market_fact;
    
----------------- 6. Display the number of customers in each region in decreasing order of no_of_customers. The result should contain columns Region, no_of_customers. ------


SELECT 
    region, COUNT(*) No_of_Customers
FROM
    cust_dimen
GROUP BY Region 
ORDER BY No_of_Customers desc;


----------------------- 7. Find the region having maximum customers (display the region name and max(no_of_customers) -------------------------------

SELECT 
    region, MAX(no_of_customers)
FROM
    (SELECT 
        region, COUNT(*) No_of_Customers
    FROM
        cust_dimen
    GROUP BY region
    ORDER BY No_of_Customers DESC) a;


-------- 8. Find all the customers from Atlantic region who have ever purchased ‘TABLES’ and the number of tables purchased (display the customer name, no_of_tables purchased) ---------

SELECT 
    c.customer_name, COUNT(m.prod_id)
FROM
    cust_dimen AS c
        JOIN
    market_fact AS m ON m.cust_id = c.cust_id
        JOIN
    prod_dimen AS p ON p.prod_id = m.prod_id
WHERE
    c.region = 'atlantic'
        AND p.product_sub_category = 'Tables'
GROUP BY c.customer_name;


-------------- 9. Find all the customers from Ontario province who own Small Business. (display the customer name, no of small business owners)--------------------


SELECT 
    customer_name,
    COUNT(customer_segment) AS 'no of small business owners'
FROM
    cust_dimen
WHERE
    customer_segment = 'small business'
        AND province = 'ontario'
GROUP BY customer_name
ORDER BY customer_name DESC;

-------------- 10. Find the number and id of products sold in decreasing order of products sold (display product id, no_of_products sold) -----------------------

SELECT 
    prod_id, order_quantity AS no_of_product_sold
FROM
    market_fact
ORDER BY order_quantity DESC;


----- 11. Display product Id and product sub category whose produt category belongs to Furniture and Technlogy. The result should contain columns product id, product sub category.


SELECT 
    prod_id AS Product_id, product_sub_category
FROM
    prod_dimen
WHERE
    product_category = 'Furniture'
        OR product_category = 'Technology';
        
-------- 12. Display the product categories in descending order of profits (display the product category wise profits i.e. product_category, profits)-------------


SELECT 
    p.product_category, m.profit
FROM
    prod_dimen AS p
        JOIN
    market_fact AS m ON m.prod_id = p.prod_id
GROUP BY p.product_category
ORDER BY m.profit DESC;

----------------- 13. Display the product category, product sub-category and the profit within each subcategory in three columns. -----------------------------


SELECT 
    p.product_category, p.product_sub_category, m.profit
FROM
    prod_dimen AS p
        JOIN
    market_fact AS m ON m.prod_id = p.prod_id
GROUP BY p.product_sub_category;

----------------------------- 14. Display the order date, order quantity and the sales for the order. ---------------------------------------


SELECT 
    o.order_date, m.order_quantity, m.sales
FROM
    orders_dimen o
        JOIN
    market_fact m ON m.ord_id = o.ord_id;
    
    
----------------- 15. Display the names of the customers whose name contains the (i) Second letter as ‘R’ (ii) Fourth letter as ‘D’ ------------------------------


SELECT DISTINCT
    (customer_name)
FROM
    cust_dimen
WHERE
    customer_name LIKE '_R_D%'
ORDER BY customer_name;
    
----------- 16. Write a SQL query to to make a list with Cust_Id, Sales, Customer Name and their region where sales are between 1000 and 5000. -------------------------

SELECT 
    c.cust_id, c.customer_name, c.region, m.sales
FROM
    cust_dimen c
        JOIN
    market_fact m ON m.cust_id = c.cust_id
WHERE
    m.sales BETWEEN '1000' AND '5000'
ORDER BY sales;


-- ---------------------------------------------------17. Write a SQL query to find the 3rd highest sales. --------------------------------------------------


SELECT 
    *
FROM
    market_fact
ORDER BY sales DESC
LIMIT 1 OFFSET 2;


-- ----------------------18. Where is the least profitable product subcategory shipped the most? For the least profitable product sub-category, display the region-wise no_of_shipments and the profit made in each region in decreasing order of profits (i.e. region, no_of_shipments, profit_in_each_region)
-- ----------------------→ Note: You can hardcode the name of the least profitable product subcategory -------------------

SELECT 
    c.region,
    COUNT(DISTINCT s.ship_id) AS total_shipments,
    SUM(m.profit) AS Profit_per_Region
FROM
    market_fact AS m
        INNER JOIN
    cust_dimen AS c ON m.cust_id = c.cust_id
        INNER JOIN
    shipping_dimen AS s ON m.ship_id = s.ship_id
        INNER JOIN
    prod_dimen AS p ON m.prod_id = p.prod_id
WHERE
    p.product_sub_category IN (SELECT 
            p.product_sub_category
        FROM
            market_fact AS m
                INNER JOIN
            prod_dimen AS p ON m.prod_id = p.prod_id
        GROUP BY p.product_sub_category
        HAVING SUM(m.profit) <= ALL (SELECT 
                SUM(m.profit) AS profits
            FROM
                market_fact AS m
                    INNER JOIN
                prod_dimen AS p ON m.prod_id = p.prod_id
            GROUP BY p.product_sub_category))
GROUP BY c.region
ORDER BY profit_per_region DESC;




